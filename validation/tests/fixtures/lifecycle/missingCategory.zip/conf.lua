local Settings = { nodes = { 'probe' } }
return Settings
