local Menu = {
    id = 'animationPhysicsLab',
    title = 'Animation + physics / rig, masks, fades, joints and rolling ramp',
    category = 'Physics',
}

return Menu
