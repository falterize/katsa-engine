local Menu = {
    id = 'nightPlayer',
    title = 'Night capsule player / first + third person',
    category = 'Gameplay',
}

return Menu
