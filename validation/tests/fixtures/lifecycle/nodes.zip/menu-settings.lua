local Menu = {
    id = 'nodes',
    title = 'Nodes + attachments + cameras + UI scroll',
    category = 'UI',
}

return Menu
