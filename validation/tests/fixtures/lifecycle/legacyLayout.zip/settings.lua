local Settings = { layoutVersion = 2, nodes = { 'probe' } }
return Settings
