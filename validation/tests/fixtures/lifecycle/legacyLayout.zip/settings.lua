local Settings = { layoutVersion = 2, id = 'lifecycleFixture', nodes = { 'probe' } }
return Settings
