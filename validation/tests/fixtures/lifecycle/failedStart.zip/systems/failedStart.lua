local Observer = require('scene.scripts.behaviors.observer')
local System = {}
function System.create(state)
    local instance = Observer.create(state, 'failedStart')
    instance.start = function() error('Expected startup failure') end
    return instance
end
return System
